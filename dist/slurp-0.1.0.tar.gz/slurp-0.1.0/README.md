# slurp
Library to handle with Generalised Not Additive Models (GNAM).

They are models inspired on GAM but where you can make oeprations between splines (multiplication, division, sum).

The whole model is written in torch. Model interface `gnam` works only with `polars`.


## Small demo

```
marimo run notebok/demo.py
```
